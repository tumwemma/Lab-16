package edu.mum.wap.model;

public enum ERoleType {
	CLIENT, ADMIN;
}
