package edu.mum.wap.model;

public enum EPaymentStatus {
	PAID, PENDING, CANCELED;
}
